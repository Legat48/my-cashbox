"use strict";

// вызовы всех функций из классов
// класс настроек
setting.setDefauilSetting();
setting["interface"](); //вызов функции интерфейса
// setting.switchTheme(); //вызов функции переключения темы

setting.QRcode();
setting.useAtol();
setting.troubleAtol();
setting.useWeight();
setting.useTerminal();
setting.checklist();
setting.weekDay();
setting.firstSlip();
setting.secondSlip();
setting.fiscalPrint();
setting.useKeyboard(); // переключение клавиатуры

setting.mailPoint();
interfaceApp.dropdown();
interfaceApp.burger();
interfaceApp.formedOrders();
interfaceApp.surrender();
interfaceApp.btnAllCategory();
interfaceApp.btnFptsUpdate();
interfaceApp.btnUptadeTerminalReset();
interfaceApp.declaration();
var tokenPointVers = document.querySelector('.menu__version');

if (tokenPointVers) {
  tokenPointVers.textContent = "".concat(pointCashbox, " | ").concat(tokenPointVers.textContent);
}

getPointInfo(tokenPoint, subdomain).then(function (result) {})["catch"](function (error) {
  var errorStr = JSON.stringify(error);
  logger('Ошибка в applaying>getPointInfo \n' + errorStr);
});
checklist.tracking(); // навешивание скролла на страницу
// вертикальный скроллбар

var scrollerArr = document.querySelectorAll('.scrollbar'); // объявление скролла на плагине

scrollerArr.forEach(function (el) {
  new SimpleBar(el, {
    scrollbarMaxSize: 100,
    autoHide: true,
    clickOnTrack: false
  });
}); // catalog__category скроллбар для каталога категорий

interfaceApp.scrollFuncHoryz('.catalog__category', 38); // catalog__content скроллбар для товаров и подкатегорий

interfaceApp.scrollFuncVert('.catalog__content', 35); // receipt скроллбар для чека

interfaceApp.scrollFuncVert('.receipt', 9);