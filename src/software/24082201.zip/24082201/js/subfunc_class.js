"use strict";

var subfunc = new function () {
  this.getTime = function () {
    // запись времени
    var dataObj = '0';

    if (useAtol && !troubleAtol) {
      var timeAtol = devkkm.atolTime();
      dataObj = new Date(timeAtol);

      if (timeAtol < 0) {
        dataObj = new Date();
      }
    } else {
      dataObj = new Date();
    }

    var hours = "".concat(dataObj.getHours());

    if (hours.length != 2) {
      hours = "0".concat(hours);
    }

    var minutes = "".concat(dataObj.getMinutes());

    if (minutes.length != 2) {
      minutes = "0".concat(minutes);
    }

    var day = "".concat(dataObj.getDate());

    if (day.length != 2) {
      day = "0".concat(day);
    }

    var time = "".concat(hours, ":").concat(minutes);
    var month = "".concat(dataObj.getMonth() + 1);

    if (month.length == 1) {
      month = "0".concat(month);
    }

    var date = "".concat(dataObj.getFullYear(), "-").concat(month, "-").concat(day);
    var unix = Math.floor(dataObj.getTime() / 1000);
    ordersArr[0].time = time;
    ordersArr[0].date = date;
    ordersArr[0].unix = unix;
    return {
      time: time,
      date: date,
      unix: unix
    };
  }; // рандомные символы


  this.random = function () {
    // генератор рандомных символов
    var abc = "abcdefghijklmnopqrstuvwxyz1234567890";
    var rs = "";

    while (rs.length < 8) {
      rs += abc[Math.floor(Math.random() * abc.length)];
    }

    ;
    return rs;
  }; // взять объект чека по статусу или айди


  this.getOrderObg = function (status) {
    var idOrder = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    var ans, q;
    var ordersTableArr = []; //массив для создания чека

    var ordersArr = []; //выбранный чек
    // запрос по айди

    var qWhere = "status = ".concat(status);

    if (idOrder) {
      qWhere = "id = ".concat(Number(idOrder));
    }

    q = "SELECT id, status, currentTable, fiscalPrint, time, date, unix, orderSum, promo, idClient, accumClientPoints, clientPoints, globalCashback, interimSum, offreckoning, amount, orderSumFinal, barista, idworkdayOffline, idworkdayOnline, email,  chtype, tokenPoint, hashcode, initiallyPoints, qrtoken, certificate, endPointsCert, nameClient FROM orders WHERE ".concat(qWhere);
    logger("\u0437\u0430\u043F\u0440\u043E\u0441 \u0447\u0435\u043A\u0430 ".concat(q));

    try {
      ans = db.query(q);

      for (var i = 0; ans[i] != undefined; i++) {
        ordersTableArr.push(ans[i]);
      }

      ;
      ordersTableArr.forEach(function (e) {
        var order = new Order(e.id, e.status, e.currentTable, e.fiscalPrint, e.time, e.date, e.unix, e.orderSum, e.promo, e.idClient, e.accumClientPoints, e.clientPoints, e.globalCashback, e.email, e.interimSum, e.offreckoning, e.amount, e.orderSumFinal, e.barista, e.idworkdayOffline, e.idworkdayOnline, e.chtype, e.tokenPoint, e.hashcode, e.initiallyPoints, e.qrtoken, e.certificate, e.endPointsCert, e.nameClient); // создали чек

        ordersArr.push(order);
      });
      return ordersArr[0];
    } catch (e) {
      logger("\u0437\u0430\u043F\u0440\u043E\u0441 \u0447\u0435\u043A\u0430 ".concat(idOrder, " \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F, \u043E\u0448\u0438\u0431\u043A\u0430 ").concat(e.message, " "));

      try {
        db.conn.close();
      } catch (error) {}

      return false;
    }
  }; // взять массив товаров


  this.getProductArr = function (order) {
    try {
      var q = "SELECT id, idProd, idOrder, name, productCategory, bulkvalue, bulkuntils, price, sale, debitClientBonus, saleMaxPrice, interimPrice, offreckoningItem, cashbackPercent, amount, priceFinal, cashback, cashbackSum, productSum FROM orderItem WHERE idOrder = ".concat(Number(order.id));
      logger("\u043F\u043E \u0447\u0435\u043A\u0443 ".concat(order.id, " \u0438\u0434\u0435\u043C \u0437\u0430 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u0430\u043C\u0438 ").concat(q));

      try {
        var productAns = db.query(q);
        var productArr = [];
        var productTableArr = [];

        for (var i = 0; productAns[i] != undefined; i++) {
          productTableArr.push(productAns[i]);
        }

        ;
        productTableArr.forEach(function (e) {
          var newProduct = new Product(e.id, e.idProd, e.idOrder, e.name, e.productCategory, e.bulkvalue, e.bulkuntils, e.price, e.sale, e.debitClientBonus, e.saleMaxPrice, e.interimPrice, e.offreckoningItem, e.cashbackPercent, e.amount, e.priceFinal, e.cashback, e.cashbackSum, e.productSum);
          productArr.push(newProduct);
        });
        return productArr;
      } catch (e) {
        try {
          db.conn.close();
        } catch (error) {}

        throw e.message;
      }
    } catch (e) {
      logger("\u041E\u0448\u0438\u0431\u043A\u0430 \u0432\u0437\u044F\u0442\u0438\u044F \u0442\u043E\u0432\u0430\u0440\u043E\u0432 \u043F\u043E \u0447\u0435\u043A\u0443, \u043E\u0442\u0432\u0435\u0442 ".concat(e.message, " \u0447\u0435\u043A ").concat(Number(order.id)));
      return false;
    }
  }; // Статистика за день


  this.getDailyStat = function () {
    var resp = false;
    var respCash = false;
    var respReturn = false;
    var respCashReturn = false;
    var sum = 0,
        orders = 0,
        averageOrder = 0,
        cashSum = 0,
        cashLessSum = 0,
        cashSumReturn = 0,
        cashLessSumReturn = 0,
        returnSum = 0;

    try {
      resp = db.query("SELECT sum(orderSumFinal) as 'orderSum', count(id) as 'count', avg(orderSumFinal) as 'orderSumAvg' FROM orders WHERE status in(1,2,3) and date = '".concat(dateStrGlobal, "'"));
      respCash = db.query("SELECT sum(orderSumFinal) as 'orderSum' FROM orders WHERE status in(1,2,3) and date = '".concat(dateStrGlobal, "' and chtype = 0"));
    } catch (e) {
      db.conn.close();
    }

    try {
      respReturn = db.query("SELECT sum(orderSumFinal) as 'orderSum', count(id) as 'count', avg(orderSumFinal) as 'orderSumAvg' FROM orders WHERE status in(-1,-2,4,5) and date = '".concat(dateStrGlobal, "'"));
      respCashReturn = db.query("SELECT sum(orderSumFinal) as 'orderSum' FROM orders WHERE status in(-1,-2,4,5) and date = '".concat(dateStrGlobal, "' and chtype = 0"));
    } catch (e) {
      try {
        db.conn.close();
      } catch (error) {}
    }

    if (resp) {
      try {
        sum = resp[0].orderSum > 0 ? resp[0].orderSum : 0;
        orders = resp[0].count;
        averageOrder = resp[0].orderSum > 0 ? Math.floor(Number(resp[0].orderSumAvg)) : 0;

        if (respReturn) {
          returnSum = respReturn[0].orderSum > 0 ? Number(respReturn[0].orderSum) : 0;

          if (respCashReturn) {
            cashSumReturn = respCashReturn[0].orderSum > 0 ? Number(respCashReturn[0].orderSum) : 0;
            cashLessSumReturn = respReturn[0].orderSum > 0 ? Number(respReturn[0].orderSum) - Number(cashSumReturn) : 0;
          } else {
            cashLessSumReturn = respReturn[0].orderSum > 0 ? Number(respReturn[0].orderSum) : 0;
          }
        }

        if (respCash) {
          cashSum = respCash[0].orderSum > 0 ? respCash[0].orderSum : 0;
          cashLessSum = resp[0].orderSum > 0 ? Number(resp[0].orderSum) - Number(cashSum) : 0;
        } else {
          cashSum = 0;
        }
      } catch (error) {
        orders = 0; // кол-во чеков

        averageOrder = 0; //средний чек приход

        sum = 0; // Приход

        cashSum = 0; // приход нал

        cashLessSum = 0; // приход безнал

        returnSum = 0; // возврат

        cashSumReturn = 0, // взврат нал
        cashLessSumReturn = 0; // возврат безнал

        logger('Ошибка в getDailyStat' + error.message);
      }
    } else {
      orders = 0; // кол-во чеков

      averageOrder = 0; //средний чек приход

      sum = 0; // Приход

      cashSum = 0; // приход нал

      cashLessSum = 0; // приход безнал

      returnSum = 0; // возврат

      cashSumReturn = 0, // взврат нал
      cashLessSumReturn = 0; // возврат безнал
    }

    return {
      orders: orders,
      averageOrder: averageOrder,
      sum: sum,
      cashSum: cashSum,
      cashLessSum: cashLessSum,
      returnSum: returnSum,
      cashSumReturn: cashSumReturn,
      cashLessSumReturn: cashLessSumReturn
    };
  };
}();