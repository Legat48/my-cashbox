"use strict";

function popup(message, staticSelector) {
  // selector если указан добавить попап и не уберет его
  var popup = 'popup';
  var selector = staticSelector;
  var newItem = el('div', "".concat(popup), [el('div', "".concat(popup, "__content"), JSON.stringify(message).replace(/['"]+/g, ''))]);
  var root = document.querySelector('.alerts');

  if (selector) {
    root = document.querySelector(".".concat(selector));
    newItem.classList.add('popup_absolute');
  }

  root.appendChild(newItem);
  root.style.opacity = '1';
  setTimeout(function () {
    newItem.style.opacity = '1';
    newItem.style.transform = "translateY(0)";
  }, 30);
  setTimeout(function () {
    if (selector) return;
    newItem.style.opacity = '0';
    newItem.style.transform = "translateY(+100%)";
    setTimeout(function () {
      newItem.style.display = 'none';
    }, 300);
  }, 3000);
  clearTimeout(alertsTimeOut);
  if (selector) return;
  alertsTimeOut = setTimeout(function () {
    root.style.opacity = '0';
  }, 3300);
}