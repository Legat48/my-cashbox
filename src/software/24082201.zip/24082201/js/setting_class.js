"use strict";

var setting = new function () {
  this.setDefauilSetting = function () {
    var ans = dbMethods.getterDb('settings', {
      variable: 'tokenPoint'
    }, 'value')[0];

    if (!ans) {
      dbMethods.setterDb('settings', {
        pointCashbox: null,
        // номер точки
        tokenPoint: null,
        //токен точки
        tokenWorkdayOnline: null,
        // онлайн токен смены
        tokenWorkdayOffline: null,
        //токен смены онлайн
        barista: null,
        // имя баристы
        employed: 1,
        //трудоустроен
        pincode: null,
        // пинкод под который открыли смену
        darkTheme: 0,
        // темная тема, 1-вкл *
        // fiscalPrint: 1, // //печатать ли чек *
        useQRcode: 0,
        //  использовать QRcode *
        useTerminal: 0,
        // использовать терминал *
        useWeight: 0,
        // использовать весы
        useAtol: 0,
        //  использовать атол *
        firstSlip: 0,
        //  печать панк слипа *
        secondSlip: 1,
        //  печать второго банк слипа *
        tax: '0',
        // НДС *
        checklist: 0,
        //  использовать чеклисты
        scales: 'COM1',
        //   порт весов *
        mailPoint: 'orders@coffeeway.ru',
        //  адрес почты для отправки чека
        currency: null,
        //  валюта на точке
        roundPrice: 0,
        //  округление до целых 0 округляем 1 не округляем
        subdomain: 'ru',
        // регион
        weekDay: null,
        // день недели
        useKeyboard: 1,
        // использование клавиатуры
        tokenQR: null,
        //токен точки для оплаты QR кодом
        keyQR: null,
        // ключ точки для оплаты QR кодом
        troubleAtol: 0 // аварийный режим атола

      }, 'vertical');
      return;
    }

    if (ans === 'null') {
      dbMethods.setterDb('settings', {
        pointCashbox: null,
        // номер точки
        tokenPoint: null,
        //токен точки
        tokenWorkdayOnline: null,
        // онлайн токен смены
        tokenWorkdayOffline: null,
        //токен смены онлайн
        barista: null,
        // имя баристы
        employed: 1,
        //трудоустроен
        pincode: null,
        // пинкод под который открыли смену
        darkTheme: 0,
        // темная тема, 1-вкл *
        // fiscalPrint: 1, // //печатать ли чек *
        useAtol: 0,
        //  использовать атол *
        useTerminal: 0,
        // использовать терминал *
        useWeight: 0,
        // использовать весы
        checklist: 0,
        //  использовать чеклисты
        firstSlip: 0,
        //  печать панк слипа *
        secondSlip: 0,
        //  печать второго банк слипа *
        tax: '0',
        // НДС *
        scales: 'COM1',
        //   порт весов *
        mailPoint: 'orders@coffeeway.ru',
        //  адрес почты для отправки чека
        currency: null,
        //  валюта на точке
        roundPrice: 0,
        //  округление до целых 0 округляем 1 не округляем
        subdomain: 'ru',
        // регион
        weekDay: null,
        // день недели
        useKeyboard: 1,
        // использование клавиатуры
        tokenQR: null,
        //токен точки для оплаты QR кодом
        keyQR: null,
        // ключ точки для оплаты QR кодом
        troubleAtol: 0 // аварийный режим атола

      }, 'vertical');
    }

    var troubleAtol = dbMethods.getterDb('settings', {
      variable: 'troubleAtol'
    }, 'value')[0];

    if (!troubleAtol) {
      dbMethods.setterDb('settings', {
        troubleAtol: 0
      }, 'vertical');
    }

    if (ans.length > 5) {
      var _subdomain = dbMethods.getterDb('settings', {
        variable: 'subdomain'
      }, 'value')[0];
      setting.updateMenu(ans, _subdomain);
    }
  }; // скрытие и проявление настроек


  this["interface"] = function () {
    settingBtn.addEventListener('click', function () {
      settingRoot.classList.add('setting');
    });
    settingBox.addEventListener('click', function (e) {
      if (!e.target.closest('.setting__card')) {
        settingRoot.classList.remove('setting');
      }
    });
  }; //переключение темы
  // this.switchTheme = function () {
  //   const darkThemeBtn = document.querySelector('#dark-theme');
  //   const markerToggle = document.querySelector('#dark-theme-toggle');
  //   const style = document.getElementById('style');
  //   const hta = document.getElementById('hta_id');
  //   let ans = dbMethods.getterDb('settings', { variable: 'darkTheme' }, 'value')[0]
  //   darkTheme = Number(ans[0]);
  //   if (darkTheme === 0) {
  //     markerToggle.checked = false;
  //   } else {
  //     markerToggle.checked = true;
  //     const link = document.createElement('link');
  //     link.rel = "stylesheet";
  //     link.href = "css/styles-dark.css";
  //     link.id = 'dark';
  //     hta.insertBefore(link, style.nextSibling);
  //   }
  //   darkThemeBtn.addEventListener('click', ((e)=> {
  //     if (markerToggle.checked) {
  //       markerToggle.checked = false;
  //       hta.removeChild(document.getElementById('dark'));
  //       dbMethods.updateDb('settings', {value: 0}, { variable: 'darkTheme' } )
  //     } else {
  //       markerToggle.checked = true;
  //       const link = document.createElement('link');
  //       link.rel = "stylesheet";
  //       link.href = "css/styles-dark.css";
  //       link.id = 'dark';
  //       hta.insertBefore(link, style.nextSibling);
  //       dbMethods.updateDb('settings', {value: 1}, { variable: 'darkTheme' } )
  //     }
  //   }))
  // }
  // кнопка использования атола


  this.useAtol = function () {
    try {
      devkkm.init();
      logger('Фискальник инициализован');
    } catch (e) {
      logger("\u041E\u0448\u0438\u0431\u043A\u0430 \u0438\u043D\u0438\u0446\u0438\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0444\u0438\u0441\u043A\u0430\u043B\u044C\u043D\u0438\u043A\u0430 ".concat(e.message));

      if (typeof FRconsole != 'undefined') {
        FRconsole.value += "Ошибка ФР библиотеки!" + e.message + " \n";
      }
    }

    var useAtolBtn = document.querySelector('#atol-us');
    var markerToggle = document.querySelector('#atol-us-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'useAtol'
    }, 'value')[0];
    useAtol = Number(ans);

    if (useAtol === 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    useAtolBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        useAtol = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'useAtol'
        });
      } else {
        markerToggle.checked = true;
        useAtol = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'useAtol'
        });
      }
    });
  };

  this.troubleAtol = function () {
    // проверка на наличие не синхронизированных чеков
    if (useAtol) {
      var order = false;
      var productArr = false;
      order = subfunc.getOrderObg(1);

      if (order) {
        productArr = subfunc.getProductArr(order);

        if (productArr) {
          troubleAtol = 1;
          document.querySelector('#trouble-atol-toggle').checked = true;
          dbMethods.updateDb('settings', {
            value: 1
          }, {
            variable: 'troubleAtol'
          });
          popup('отправка чека на печать');
          logger("\u043F\u0435\u0447\u0430\u0442\u044C \u0447\u0435\u043A\u0430 \u0441 \u0430\u0439\u0434\u0438 ".concat(order.id));

          if (devkkm.printOrder(order, productArr)) {
            var q = "UPDATE orders SET status = 2 WHERE id = ".concat(order.id);

            try {
              db.query(q);
              logger("\u0444\u0438\u043A\u0441\u0430\u0446\u0438\u044F \u0447\u0435\u043A\u0430 \u0441 \u0430\u0439\u0434\u0438 ".concat(order.id)); // и пробуем новый чек отправить

              clearTimeout(delayPostmanAtolOrder);
              delayPostmanAtolOrder = setTimeout(postman.atolOrder, 12777);
            } catch (e) {
              popup("\u043E\u0448\u0438\u0431\u043A\u0430 \u0444\u0438\u043A\u0441\u0430\u0446\u0438\u0438 \u0447\u0435\u043A\u0430 ".concat(e.message, " \u0447\u0435\u043A ").concat(JSON.stringify(order)));
              logger("\u043E\u0448\u0438\u0431\u043A\u0430 \u0444\u0438\u043A\u0441\u0430\u0446\u0438\u0438 \u0447\u0435\u043A\u0430 ".concat(e.message, " \u0447\u0435\u043A ").concat(JSON.stringify(order)));
            }
          } else {
            popup('печать чека не удалась, проверьте фискальный регистратор и перезапустите кассу(закрыть 2 окна)! ');
            clearTimeout(delayPostmanAtolOrder);
            delayPostmanAtolOrder = setTimeout(postman.atolOrder, 15777);
          }
        } else {
          popup("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0442\u043E\u0432\u0430\u0440\u043E\u0432 \u043F\u043E \u0447\u0435\u043A\u0443 ".concat(order.id, ". \u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0442\u043E\u0440 \u0447\u0435\u043A\u043E\u0432 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D"));
        }
      } else {
        order = subfunc.getOrderObg(-1);
        logger("\u043F\u0435\u0447\u0430\u0442\u044C \u0447\u0435\u043A\u0430 \u0441 \u0430\u0439\u0434\u0438 ".concat(order.id));

        if (order) {
          productArr = subfunc.getProductArr(order);

          if (productArr) {
            troubleAtol = 1;
            document.querySelector('#trouble-atol-toggle').checked = true;
            dbMethods.updateDb('settings', {
              value: 1
            }, {
              variable: 'troubleAtol'
            });
            popup('отправка чека на печать возврата');

            if (devkkm.printReturtOrder(order, productArr)) {
              clearTimeout(delayPostmanAtolOrder);
              delayPostmanAtolOrder = setTimeout(postman.atolOrder, 12777);
            } else {
              popup('печать возврата чека не удалась, проверьте фискальный регистратор!');
              clearTimeout(delayPostmanAtolOrder);
              delayPostmanAtolOrder = setTimeout(postman.atolOrder, 15777);
            }
          } else {
            popup("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F \u0442\u043E\u0432\u0430\u0440\u043E\u0432 \u043F\u043E \u0447\u0435\u043A\u0443 ".concat(order.id, ". \u0421\u0438\u043D\u0445\u0440\u043E\u043D\u0438\u0437\u0430\u0442\u043E\u0440 \u0447\u0435\u043A\u043E\u0432 \u043E\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D"));
          }
        } else {
          troubleAtol = 0;
          document.querySelector('#trouble-atol-toggle').checked = false;
          dbMethods.updateDb('settings', {
            value: 0
          }, {
            variable: 'troubleAtol'
          });
          popup('Синхронизация остановлена, касса переведена в безаварийный режим');
        }
      }
    }

    var troubleAtolBtn = document.querySelector('#trouble-atol');
    var markerToggle = document.querySelector('#trouble-atol-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'troubleAtol'
    }, 'value')[0];
    troubleAtol = Number(ans);

    if (troubleAtol === 1) {
      markerToggle.checked = true;
      postman.atolOrder();
    } else {
      markerToggle.checked = false;
    }

    troubleAtolBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        troubleAtol = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'troubleAtol'
        });
      } else {
        markerToggle.checked = true;
        troubleAtol = 1;
        postman.atolOrder();
        document.querySelector('#trouble-atol-toggle').checked = true;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'troubleAtol'
        });
      }
    });
  }; // кнопка использования QRcode


  this.QRcode = function () {
    var useQRcodeBtn = document.querySelector('#QRcode');
    var markerToggle = document.querySelector('#QRcode-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'useQRcode'
    }, 'value')[0];
    useQRcode = Number(ans);

    if (useQRcode === 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    useQRcodeBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        useQRcode = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'useQRcode'
        });
      } else {
        markerToggle.checked = true;
        useQRcode = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'useQRcode'
        });
      }
    });
  }; // кнопка использования терминала


  this.useTerminal = function () {
    var useTerminalBtn = document.querySelector('#terminal-us');
    var markerToggle = document.querySelector('#terminal-us-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'useTerminal'
    }, 'value')[0];
    useTerminal = Number(ans);

    if (useTerminal === 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    useTerminalBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        useTerminal = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'useTerminal'
        });
      } else {
        markerToggle.checked = true;
        useTerminal = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'useTerminal'
        });
      }
    });
  }; // кнопка использования терминала


  this.useWeight = function () {
    var useWeightBtn = document.querySelector('#weight-us');
    var markerToggle = document.querySelector('#weight-us-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'useWeight'
    }, 'value')[0];
    useWeight = Number(ans);

    if (useWeight === 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    useWeightBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        useWeight = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'useWeight'
        });
      } else {
        markerToggle.checked = true;
        useWeight = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'useWeight'
        });
      }
    });
  }; // день недели


  this.weekDay = function () {
    var date = new Date();
    weekDay = date.getDay();
    dbMethods.updateDb('settings', {
      value: weekDay
    }, {
      variable: 'weekDay'
    });
  };

  this.firstSlip = function () {
    var firstSlipBtn = document.querySelector('#first-slip');
    var markerToggle = document.querySelector('#first-slip-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'firstSlip'
    }, 'value')[0];
    firstSlip = Number(ans);

    if (firstSlip === 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    firstSlipBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        firstSlip = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'firstSlip'
        });
      } else {
        markerToggle.checked = true;
        firstSlip = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'firstSlip'
        });
      }
    });
  };

  this.secondSlip = function () {
    var secondSlipBtn = document.querySelector('#second-slip');
    var markerToggle = document.querySelector('#second-slip-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'secondSlip'
    }, 'value')[0];
    secondSlip = Number(ans);

    if (secondSlip === 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    secondSlipBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        secondSlip = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'secondSlip'
        });
      } else {
        markerToggle.checked = true;
        secondSlip = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'secondSlip'
        });
      }
    });
  };

  this.fiscalPrint = function () {
    var electronicOrderToggle = document.querySelector('#electronic-order-toggle');
    var electronicOrderBtn = document.querySelector('#electronic-order'); // electronicOrderToggle.checked = false;

    electronicOrderBtn.addEventListener('click', function (e) {
      if (electronicOrderToggle.checked) {
        electronicOrderToggle.checked = false;
        fiscalPrint = 0;
      } else {
        electronicOrderToggle.checked = true;
        fiscalPrint = 1;
      }
    });
  };

  this.checklist = function () {
    var checklistBtn = document.querySelector('#use-checklist');
    var markerToggle = document.querySelector('#use-checklist-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'checklist'
    }, 'value')[0];
    useChecklist = Number(ans);

    if (useChecklist == 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    checklistBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        useChecklist = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'checklist'
        });
      } else {
        markerToggle.checked = true;
        useChecklist = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'checklist'
        });
      }
    });
  };

  this.mailPoint = function () {
    var mailPointWrap = document.querySelector('#mail-point-wrap');
    var mailPointBtn = document.querySelector('#mail-point-btn');
    var mailPointMailBtn = document.querySelector('#mail-point-mail-btn');
    var mailPointInput = document.querySelector('#mail-point-input');
    var ans = dbMethods.getterDb('settings', {
      variable: 'mailPoint'
    }, 'value')[0];
    mailPoint = ans;
    mailPointBtn.textContent = mailPoint; // появление ввода почты

    mailPointBtn.addEventListener('click', function (e) {
      e.target.closest('.setting__card').classList.add('setting__card_transparent');
      mailPointWrap.classList.add('setting__item_active-mail');
    }); // скрытие ввода при любом клике кроме как на инпут

    window.addEventListener('click', function (e) {
      if (!e.target.closest('#mail-point-btn') && !e.target.matches('.setting__input') && !e.target.closest('.keyboard')) {
        mailPointWrap.classList.remove('setting__item_active-mail');
      }
    });
    mailPointMailBtn.addEventListener('click', function (e) {
      mailPoint = mailPointInput.value;
      mailPointBtn.textContent = mailPoint;
      dbMethods.updateDb('settings', {
        value: mailPoint
      }, {
        variable: 'mailPoint'
      });
    });
  };

  this.scalesPort = function () {
    var btnScalesList = document.querySelectorAll('.dropdown__item-btn_scales');
    var btnScalesArr = Array.prototype.slice.call(btnScalesList); // делает привычный массив из нодлиста

    var textInfoBtn = document.querySelector('#scales-display-info');
    var ans = dbMethods.getterDb('settings', {
      variable: 'scales'
    }, 'value')[0];
    scales = ans;
    textInfoBtn.textContent = scales;
    btnScalesArr.forEach(function (e) {
      e.addEventListener('click', function (e) {
        scales = e.textContent;
        textInfoBtn.textContent = scales;
        dbMethods.updateDb('settings', {
          value: scales
        }, {
          variable: 'scales'
        });
      });
    });
  };

  this.globalVariables = function () {
    var ans, q;
    q = "SELECT value FROM settings WHERE variable = 'pointCashbox' or variable = 'tokenPoint' or variable = 'tokenWorkdayOnline' or variable = 'tokenWorkdayOffline' or variable = 'barista' or variable = 'employed' or variable = 'subdomain' or variable = 'currency' or variable = 'tokenQR' or variable = 'keyQR'";
    ans = db.query(q); // alert(JSON.stringify(ans)) // 9 раз

    pointCashbox = ans[0].value;
    tokenPoint = ans[1].value;
    idworkdayOnline = ans[2].value;
    idworkdayOffline = ans[3].value;
    barista = ans[4].value;
    employed = ans[5].value;
    currency = ans[6].value;
    subdomain = ans[7].value;

    try {
      tokenQR = ans[8].value; //токен точки для оплаты QR кодом
    } catch (_unused) {}

    try {
      keyQR = ans[9].value; //токен точки для оплаты QR кодом
    } catch (_unused2) {}
  };

  this.useKeyboard = function () {
    var useKeyboardBtn = document.querySelector('#keyboard-use');
    var markerToggle = document.querySelector('#keyboard-toggle');
    var ans = dbMethods.getterDb('settings', {
      variable: 'useKeyboard'
    }, 'value')[0];
    useKeyboard = Number(ans);

    if (useKeyboard === 1) {
      markerToggle.checked = true;
    } else {
      markerToggle.checked = false;
    }

    useKeyboardBtn.addEventListener('click', function (e) {
      if (markerToggle.checked) {
        markerToggle.checked = false;
        useKeyboard = 0;
        dbMethods.updateDb('settings', {
          value: 0
        }, {
          variable: 'useKeyboard'
        });
      } else {
        markerToggle.checked = true;
        useKeyboard = 1;
        dbMethods.updateDb('settings', {
          value: 1
        }, {
          variable: 'useKeyboard'
        });
      }
    });
  }; // получить меню c Api


  this.getMenu = function (token, subdomain) {
    return new Promise(function (resolve, reject) {
      ieFetch({
        method: 'POST',
        url: api + "api/terminal/menu?" + "subdomain=".concat(subdomain, "&token=").concat(token) // https://bridge.cwsystem.ru/engine/kassa/popularproducts/popular

      }).then(function (json) {
        var res = JSON.parse(json);
        if (!res) reject('Пустой ответ в getMenu');

        if (res.type === 'error') {
          reject(res.data.msg);
          return;
        }

        if (res.type === 'success' && res.data.length > 0) {
          try {
            resolve(res);
          } catch (error) {
            reject('Ошибка при получении тех карт');
          }
        }
      })["catch"](function (e) {
        reject('Сетевая ошибка в getMenu\n' + "".concat(JSON.stringify(e)));
      });
    });
  };

  this.updateMenu = function (tokenPoint, subdomain) {
    var _this = this;

    // получение и перезапись меню
    setting.globalVariables();

    if (tokenPoint.length > 0) {
      this.getMenu(tokenPoint, subdomain).then(function (res) {
        if (res) {
          try {
            getDiscounts(tokenPoint, subdomain)["catch"](function () {
              // получение скидок и обновление дб
              popup('Ошибка при обновлении скидок');
            }); //1.2

            if (res.hasOwnProperty('data')) {
              if (res.data.length > 0) {
                var menu = JSON.stringify(res);
                menuApp.writeJson('menuDb', menu);
              }
            }

            _this.getPopularMenu(tokenPoint, pointCashbox).then(function (resp) {
              try {
                if (resp.type == 'success') {
                  popularArray = resp.data;
                } else {
                  popularArray = [];
                }

                preloader.preloaderOff();
              } catch (error) {
                popup('Не удалось получить популярное меню');
                preloader.preloaderOff();
                popularArray = [];
              }
            });
          } catch (error) {
            alert(error.message);
          }
        }
      })["catch"](function () {
        // если получить меню онлайн не удалось:
        try {} catch (error) {
          alert(error.message);
        }
      });
    }
  };

  this.getPopularMenu = function (tokenPoint, pointCashbox) {
    return new Promise(function (resolve, reject) {
      ieFetch({
        method: 'POST',
        url: "https://bridge.cwsystem.ru/engine/kassa/popularproducts/popular?" + "token=".concat(tokenPoint, "&point=").concat(pointCashbox) // https://bridge.cwsystem.ru/engine/kassa/popularproducts/popular

      }).then(function (json) {
        var res = JSON.parse(json);
        if (!res) reject('Пустой ответ в getPopularMenu');

        if (res.type === 'error') {
          reject(res.data.msg);
          return;
        }

        if (res.type === 'success') {
          try {
            resolve(res);
          } catch (error) {
            reject('Ошибка при получении тех карт');
          }
        }
      })["catch"](function (e) {
        reject('Сетевая ошибка в getPopularMenu\n' + "".concat(JSON.stringify(e)));
      });
    });
  };
}();