"use strict";

var menuApp = new function Menu() {
  //открытие файла меню.
  this.openJson = function (name) {
    try {
      var iStream = fso.OpenTextFile("resourses\\".concat(name, ".JSON"), 1, false);

      if (!iStream) {
        alert("ошибка открытия файла меню. Дальнейшая работа кассы невозможна" + "resourses\\".concat(name, ".JSON"));
        logger("\u043E\u0448\u0438\u0431\u043A\u0430 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u044F \u0444\u0430\u0439\u043B\u0430 \u043C\u0435\u043D\u044E: resourses\\".concat(name, ".JSON"));
        return;
      }

      var data = iStream.ReadLine(); // Usually looped for several lines

      iStream.Close();
      return data;
    } catch (error) {
      logger("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u043E\u0442\u043A\u0440\u044B\u0442\u0438\u0438 \u0444\u0430\u0439\u043B\u044B \u043C\u0435\u043D\u044E".concat(error.message));
    }
  }; // перезапись меню, вызывается если пришел ответ с сервера с массивом меню


  this.writeJson = function (name, content) {
    try {
      var iStream = fso.OpenTextFile("resourses\\".concat(name, ".JSON"), 2, true);

      if (!iStream) {
        alert("Can't open file" + "resourses\\".concat(name, ".JSON"));
        return;
      }

      iStream.WriteLine(content);
      iStream.Close();
      carrentArray = []; //обнуление глобального массива
    } catch (error) {
      logger("\u043E\u0448\u0438\u0431\u043A\u0430 \u0432 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 writeJson ".concat(error.message));
    }
  }; //подгрузка массива


  this.load = function (fileName, filterByParent, filterByName) {
    try {
      //если глобальный массив существует возвращаем массив меню
      if (carrentArray.length > 0) {
        if (filterByName) {
          var _data2 = carrentArray.filter(function (el) {
            return el.name.toString().toLowerCase().includes(filterByName) && (el.type === 'product' || el.type === 'promotion');
          });

          return _data2;
        }

        var _data = carrentArray.filter(function (el) {
          return el.parent === filterByParent;
        });

        return _data;
      } // открытие меню из файла


      var mdata = this.openJson(fileName);
      var jsn = JSON.parse(mdata);
      var menu = jsn.data;
      carrentArray = menu || []; //присваивание к глобальной переменной меню

      scannerObg = {}; // обновление массива меню для сканера
      // коррекция меню от лишних символов

      if (carrentArray.length > 0) {
        carrentArray.forEach(function (e) {
          e.name = e.name.split('\t').join(''); //очитска меню по \t

          e.name = e.name.split('\n').join(''); //очитска меню по \n

          e.name = e.name.split('"').join(''); //очитска меню по "

          e.name = e.name.split('\\').join('/'); //очитска меню по /
        });
      } //создание объекта меню для сканера


      if (carrentArray.length > 0) {
        carrentArray.forEach(function (e) {
          try {
            if (e.cards) {
              if (e.cards[0].code) {
                e.cards.forEach(function (j) {
                  var id = j.id;
                  var name = e.name;
                  var parent = e.parent;
                  var product = j.product;
                  var subname = j.subname;
                  var weighted = j.weighted;
                  var bulk_value = j.bulk_value;
                  var bulk_untils = j.bulk_untils;
                  var cashback_percent = j.cashback_percent;
                  var price = j.price;
                  scannerObg["".concat(j.code)] = {
                    id: id,
                    name: name,
                    parent: parent,
                    product: product,
                    subname: subname,
                    weighted: weighted,
                    bulk_value: bulk_value,
                    bulk_untils: bulk_untils,
                    cashback_percent: cashback_percent,
                    price: price
                  };
                });
              }
            }
          } catch (e) {
            logger('Ошибка в load' + e.message);
          }
        });
      } // поиск по значению импута поиска


      if (filterByName) {
        var _data3 = menu.filter(function (el) {
          return el.name.toString().toLowerCase().includes(filterByName) && (el.type === 'product' || el.type === 'promotion');
        });

        return _data3;
      } // фильтр по родителю для отрисовки товаров и подкатегорий


      var data = menu.filter(function (el) {
        return el.parent === filterByParent;
      }) || [];
      var dataCategory = menu.filter(function (el) {
        return el.type === 'category';
      });

      if (dataCategory.length > 0) {
        dataCategory.forEach(function (element) {
          // создание массивоподобного объета для отрисовки категорий
          if (!allCategoryList.hasOwnProperty("".concat(element.id))) {
            allCategoryList["".concat(element.id)] = element.name;
          }
        });
      }

      return data || [];
    } catch (error) {
      logger("\u041E\u0448\u0438\u0431\u043A\u0430 \u0432 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u043C\u0435\u043D\u044E ".concat(error.message));
    }
  }; // универсальная функция отрисовки меню


  this.renderList = function (selector, data) {
    if (!data) {
      return;
    } else {
      try {
        if (data.length <= 0) {
          return;
        }
      } catch (error) {
        return;
      }
    }

    var root = document.querySelector(".".concat(selector));

    if (!root) {
      popup("\u043A\u043E\u0440\u043D\u0435\u0432\u043E\u0439 \u044D\u043B\u0435\u043C\u0435\u043D\u0442 \u043F\u043E \u0441\u0435\u043B\u0435\u043A\u0442\u043E\u0440\u0443 ".concat(selector, " \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D"));
      return;
    }

    var itemList = root.querySelector(".".concat(selector, "__list"));
    itemList.innerHTML = ''; //очистка меню
    // отрисовка слайдера категорий и меню по кнопке все категории

    if (selector === 'category' || selector === 'allCategory') {
      data.unshift({
        name: 'Популярное',
        id: 'popular'
      });
      data.forEach(function (element) {
        var newItem = el('button', "".concat(selector, "__item btn"), "".concat(element.name), {
          id: "".concat(selector).concat(element.id)
        });

        if (element.id == 1 || element.name == 'Кофейное меню' || element.id === 'popular') {
          newItem.classList.add("".concat(selector, "__item_first"));
        } // событие отрисовки товаров из категории в интерфейс


        newItem.addEventListener('click', function () {
          if (selector === 'allCategory') {
            document.getElementById('burger').click();
          }

          if (element.id === 'popular') {
            menuApp.renderList('content', menuApp.loadById('menuDb', popularArray));
          } else {
            menuApp.renderList('content', menuApp.load('menuDb', element.id));
          }
        });
        itemList.appendChild(newItem);
      });
      return;
    } // отрисовка каточек в интерфейс


    if (selector === 'content') {
      data.forEach(function (element) {
        //отрисовка в интерфейс подкатегории
        if (element.type === 'category') {
          var newItem = el('div', "".concat(selector, "__item"), [el('button', "".concat(selector, "__title btn"), "".concat(element.name))], {
            id: "subCategory-".concat(element.id)
          });
          newItem.addEventListener('click', function (e) {
            interfaceApp.focusReset(); //сброс фокуса

            menuApp.renderList('content', menuApp.load('menuDb', element.id));
          });
          itemList.appendChild(newItem);
        } // отрисовка в интерфейс товара


        if (element.type === 'product' || element.type === 'promotion') {
          var buttonsWrapper = el('div', "".concat(selector, "__box-unit"));

          var _newItem = el('div', "".concat(selector, "__item"), [el('button', "".concat(selector, "__title btn"), "".concat(element.name)), buttonsWrapper], {
            id: "product-".concat(element.id)
          }); // если это техкарта в категории акци


          if (element.hasOwnProperty('products')) {
            if (!element.enable) return;
            element.products.forEach(function (card, i) {
              if (i > 0) return;
              var newItemButton = el('button', "".concat(selector, "__unit btn btn_hover"), [el('div', "".concat(selector, "__unit-value"), "".concat(element.price).concat(currency)), el('div', "".concat(selector, "__unit-price"), "")]);
              newItemButton.addEventListener('click', function (e) {
                interfaceApp.focusReset(); //сброс фокуса

                if (card.weighted) {
                  card.name = element.name;
                  card.parent = element.parent;

                  try {
                    interfaceApp.weigher(card);
                  } catch (error) {
                    alert(error.message);
                  }

                  return;
                }

                var amount = 1;
                var maxSale = 1; //запись в базу данных и в глобальный объект товара

                entry.product(Number(element.id), element.name, card.bulk_value || 1, card.bulk_untils || 'шт', Number(element.price), Number(amount), 0, Number(element.parent), maxSale);
              });
              buttonsWrapper.appendChild(newItemButton);
            });
            itemList.appendChild(_newItem);
            return;
          }

          element.cards.forEach(function (card) {
            var newItemButton = el('button', "".concat(selector, "__unit btn btn_hover"), [el('div', "".concat(selector, "__unit-value"), "".concat(card.bulk_value, " ").concat(card.bulk_untils)), el('div', "".concat(selector, "__unit-price"), "".concat(card.price).concat(currency))]);
            newItemButton.addEventListener('click', function (e) {
              interfaceApp.focusReset();

              if (card.weighted) {
                card.name = element.name;
                card.parent = element.parent;

                try {
                  interfaceApp.weigher(card);
                } catch (error) {
                  alert(error.message);
                }

                return;
              }

              var amount = 1;
              entry.product(Number(card.id), element.name, card.bulk_value, card.bulk_untils, Number(card.price), Number(amount), Number(card.cashback_percent), Number(element.parent));
            });
            buttonsWrapper.appendChild(newItemButton);
          });
          itemList.appendChild(_newItem);
        }
      });
    }
  }; // меню по айдишникам


  this.loadById = function (fileName, arrId) {
    try {
      //если глобальный массив существует возвращаем массив меню
      if (carrentArray.length > 0) {
        popCarrentArray = carrentArray;
        return popCarrentArray.filter(function (el) {
          return arrId.indexOf("".concat(el.id)) != '-1' && (el.type === 'product' || el.type === 'promotion');
        });
      } // открытие меню из файла


      var mdata = this.openJson(fileName);
      var jsn = JSON.parse(mdata);
      var menu = jsn.data;
      popCarrentArray = menu || []; //присваивание к глобальной переменной меню
      // коррекция меню от лишних символов

      popCarrentArray = popCarrentArray.filter(function (el) {
        return arrId.indexOf("".concat(el.id)) != '-1' && (el.type === 'product' || el.type === 'promotion');
      });

      if (popCarrentArray.length > 0) {
        popCarrentArray.forEach(function (e) {
          e.name = e.name.split('\t').join(''); //очитска меню по \t

          e.name = e.name.split('\n').join(''); //очитска меню по \n

          e.name = e.name.split('"').join(''); //очитска меню по "

          e.name = e.name.split('\\').join('/'); //очитска меню по /
        });
      }

      return popCarrentArray || [];
    } catch (error) {
      logger("\u041E\u0448\u0438\u0431\u043A\u0430 \u0432 \u0444\u0443\u043D\u043A\u0446\u0438\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0438 \u043C\u0435\u043D\u044E \u043F\u043E\u043F\u0443\u043B\u044F\u0440\u043D\u044B\u0445 \u0442\u043E\u0432\u0430\u0440\u043E\u0432 ".concat(error.message));
    }
  };
}();