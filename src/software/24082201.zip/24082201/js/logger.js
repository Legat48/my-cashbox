"use strict";

function AddLeft(str, add, len) {
  // Потому что в JScript нет функций форматированного вывода
  str = String(str);

  while (str.length < len) {
    str = add + str;
  }

  return str;
}

function logger(Text) {
  var dumpFolder = "LOGs\\";
  var today = new Date();
  var dumpFile = today.getFullYear() + '_' + AddLeft(today.getMonth() + 1, '0', 2) + '_' + AddLeft(today.getDate(), '0', 2) + ".txt";
  fso = new ActiveXObject("Scripting.FileSystemObject");
  if (!fso.FolderExists(dumpFolder)) fso.CreateFolder(dumpFolder);
  var ts = fso.OpenTextFile(dumpFolder + dumpFile, 8, true);
  var txt = AddLeft(today.getHours(), '0', 2) + ':' + AddLeft(today.getMinutes(), '0', 2) + ':' + AddLeft(today.getSeconds(), '0', 2) + " " + Text;
  ts.WriteLine(txt);
  ts.Close();
}